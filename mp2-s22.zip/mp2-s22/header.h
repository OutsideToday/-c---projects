#ifndef HEADER_H
#define HEADER_

void displaySeats(char *seats);


#endif /* HEADER_H */
